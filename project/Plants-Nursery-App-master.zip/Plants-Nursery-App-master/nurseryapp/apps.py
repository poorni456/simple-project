from django.apps import AppConfig


class NurseryappConfig(AppConfig):
    name = 'nurseryapp'
